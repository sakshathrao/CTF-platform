NORTH PIER WORKSPACE RECOVERY
Known folders: dispatch, logs, inventory.
The latest active handover is somewhere under dispatch/active.
Some entries may not appear in a normal directory listing.
