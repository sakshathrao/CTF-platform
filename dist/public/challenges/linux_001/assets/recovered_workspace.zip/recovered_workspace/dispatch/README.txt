Active records are separate from archived records. A complete listing includes dot-prefixed entries.
