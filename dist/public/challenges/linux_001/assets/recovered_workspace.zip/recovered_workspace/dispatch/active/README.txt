Temporary and handover material may use dot-prefixed names. The latest handover is inside a hidden directory.
