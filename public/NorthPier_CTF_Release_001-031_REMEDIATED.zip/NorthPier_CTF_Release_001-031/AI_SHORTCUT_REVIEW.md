# AI-assisted shortcut review — revised release 001–031

## Remediation applied
- Challenge 010 no longer states the specific record slot or exact steps; the restricted marker is encoded in the record instead of appearing as a raw flag string. It remains a beginner static exposure exercise, not an AI-resistant exploit.
- Challenge 011 no longer distributes a ready-to-run SQL query.
- Challenges 019, 025, 026 and 030 no longer distribute full-solver starter scripts.
- Challenge 020 no longer distributes the utility's C source.
- Challenges 023 and 027 no longer include loose duplicate evidence trees outside their archive artifacts.
- Challenge 013 now has a local continuity index, avoiding a hard dependency on Internet Archive availability.

## Remaining risk
Many challenges are intentionally static and have finite evidence sets. An AI assistant with access to the full participant package can still inspect PCAPs, PDFs, SQLite databases, binaries, images, archive contents and structured evidence. The applied changes address accidental shortcuts and reduce answer disclosure in player-facing guides; they do not guarantee that AI will be unable to solve a challenge.

For the dynamic Local Browser VM set, use per-team randomization, unique flags, live service/filesystem state, and progressive hints. Keep full scripts, flags and exact solve paths organizer-only.
