# North Pier CTF — Audit remediation update (001–031)

## Applied in this revised release

- **010 The Forgotten Cookie:** removed the exact slot number and command-by-command walkthrough from participant-facing copy; changed the raw flag in the restricted JSON record to Base64; clarified that this is an introductory static client-side exposure simulation, not a server-side authorization bypass.
- **011 The Last Download:** removed the ready-to-run SQL query from the player package and embedded evidence bundle; removed the direct query handout link. The database and supporting evidence remain available.
- **013 The First Footprint:** added a contestant-accessible offline capture index and updated the page/metadata/README so the challenge can be completed if the public Wayback service is unreachable. The organizer-only fallback page that directly disclosed the answer remains private.
- **019, 025, 026 and 030:** removed the full-solver starter scripts from player packages, embedded evidence bundles and page links. Participant objectives now describe the investigation without prescribing the complete algorithm.
- **020 The Quiet Diagnostic:** removed `quietdiag.c` from the player package; retained it only in the organizer archive. The executable and supporting evidence remain.
- **023 The Map Left Behind:** removed the loose extracted `portal23/` tree. Participants must use the supplied archive.
- **027 The Timer's Last Tick:** removed the loose extracted `host27/` tree. Participants must use the supplied tarball.
- Updated the affected organizer package player copies and SHA-256 player manifests.

## Important limitation

These changes remove accidental solution disclosures and simplify the intended participant path. They do **not** make static evidence AI-proof: a participant may still upload a complete static evidence package to an AI assistant with file-analysis capability. Per-team randomized evidence/flags and live VM investigation are the recommended next step for stronger resistance to answer sharing and direct lookup.

## Verification scope

The revised bundle was checked for archive integrity, participant/organizer package pairing, absence of the removed player files, refreshed player SHA-256 manifests, and challenge-page local link consistency. Live backend `/solve`, event WebSocket, SQLite schema and production-browser behavior still require a smoke test against the actual platform.
