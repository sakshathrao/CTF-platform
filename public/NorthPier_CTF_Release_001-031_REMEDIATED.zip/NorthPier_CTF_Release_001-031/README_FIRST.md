# North Pier CTF — Canonical release 001–031

Revised release: this bundle contains all 31 participant ZIPs and 31 matching organizer ZIPs, with audit remediations applied.

- `PLAYER_PACKAGES/`: distribute only these ZIPs to participants.
- `ORGANIZER_PACKAGES/`: private flags, hints, solutions, SQL and deployment notes. Never place these in the public web root.
- `challenges_registry_entries_001_031.js` and `registry_entries_001_031.json`: current platform registry entries.
- `AUDIT_REMEDIATION_REPORT.md`: audit fixes and newly created challenge coverage.
- `AI_SHORTCUT_REVIEW.md`: file-aware AI shortcut assessment and limitations.
- `QA_RESULTS.txt`: per-check automated results.
- `ctf_full_audit_report.md`: original audit.

Install:
1. Back up the platform and event SQLite DB.
2. Merge each player package's `public/` directory into the Vite public directory. Challenges 001–002 retain the documented root-layout exception; follow their README.
3. Merge the combined registry entries into the platform registry.
4. Apply organizer SQL after inspecting the actual SQLite schema.
5. Start the API and frontend; test correct and incorrect submissions with a disposable team.
6. Never copy `author_only/` files into the public web root.

Review `AUDIT_REMEDIATION_REPORT.md` and `AI_SHORTCUT_REVIEW.md` for the applied changes and remaining AI-assistance limitations.

- `REMEDIATION_QA_RESULTS.txt`: post-remediation verification results for the revised release.
