# North Pier CTF — Full Challenge QA Audit

**Audit date:** 10 November 2026  
**Scope:** Canonical Challenge 001–031 player and author packages  
**Purpose:** Solvability, asset integrity, unintended shortcuts / AI-assisted solving, beginner readiness, and compatibility with the existing local CTF platform.

---

## 1. Executive summary

The 31 numbered challenges are **individually solvable**. I independently reconstructed the intended result for all 31 from the participant evidence, checked the files used by each solve, and confirmed the organizer flag values. The 31 author-side SQL scripts also executed successfully against a test SQLite schema seeded with placeholder rows 1–26; the resulting rows 1–31 matched the author `flag.txt` files.

That does **not** mean the full set is ready to deploy unchanged. I found the following issues:

| Priority | Challenge(s) | Finding | Required action |
|---|---|---|---|
| **Blocker** | 027–031 | Registry entries use `path` and `metadata`, while the current platform UI reads `link` and `description`. | Convert these five entries to the platform's existing registry shape before deployment. |
| **High** | 010 | The flag is directly present in the public `entries/18.json` record. Changing the cookie is not required to obtain it. | Reframe this explicitly as a client-side exposure lesson, or redesign it with a server-side challenge endpoint. |
| **High** | 023 | A loose duplicate of the intended portal snapshot is in the player ZIP, including the original internal source and source map. | Remove the top-level `portal_snapshot/` duplicate; retain the supplied nested evidence ZIP only. |
| **High** | 027 | A loose duplicate of the intended host snapshot is in the player ZIP, including the target environment file. | Remove top-level `host_snapshot/`; retain the intended tarball only. |
| **Medium** | 022 | A loose duplicate of the Git repository is in the player ZIP in addition to the intended webroot archive. | Remove top-level `repo_work/` to make the intended archive extraction part of the task. |
| **Medium** | 020 | The Linux ELF is executable in ZIP metadata, but the player steps do not explicitly tell beginners to run `chmod +x`. | Add the command and explicitly state Linux/WSL2 is required. |
| **Medium** | 019, 030 | The mathematical solve is valid, but neither player package gives a complete starter Python implementation. | Add a commented starter script or one worked byte/share example; consider labelling these Medium. |
| **Medium** | 008 | The clue is understandable, but the player is asked to use a bit-plane/LSB tool without a concrete install/command path. | Add a tested `zsteg` command and a Windows/Kali setup note, or include an optional local extractor script. |
| **Low** | 001 | Its README says to extract at the project root, unlike most packs that target Vite's `public/` directory. | Align the install location and production-build instructions with the platform's static root. |
| **Ops** | 013, 024 | These rely on live Internet Archive / RDAP / BGP information. | Recheck their external records shortly before the event and prepare a fallback evidence snapshot. |

**Overall recommendation:** Keep the 31 challenges, but do not deploy the five registry entries 027–031 until corrected. Fix or consciously accept the shortcut issues in 010, 022, 023 and 027. The strongest beginner-ready material is 001–005, 007, 011–018, 021, 024–029 and 031. Challenges 019 and 030 need more instructional scaffolding; 006, 008, 009 and 020 need tool/setup notes.

## 2. Test coverage and what was actually run

### Package integrity

- 31 canonical participant ZIPs and 31 matching author ZIPs were inspected.
- All 62 canonical ZIP archives passed archive integrity checks.
- Each author package's embedded `player/` tree matched its corresponding participant package.
- No `author_only/` directory was found in participant ZIPs.
- All 31 author folders contained `flag.txt`, `solution.md`, `hints.json`, and `set_flag.sql`; all hint JSON and challenge metadata JSON parsed successfully.
- A recursive scan of nested ZIP/TAR evidence found no unsafe archive paths or broken archive members.

### Evidence formats and content

- HTML/JavaScript: all 31 participant pages' inline scripts passed Node syntax checking. In a second smoke test, every package's registry page link was resolved against the correct static root; 145 local `href`/`src`/`poster`/`data`/`action` references were checked, with zero missing local targets.
- Local evidence references: an independent HTTP-style path resolver tested **145 local links/asset references across all packages and found 0 missing targets** when interpreted against each package's documented static root. Challenges 001–002 use a different root layout and need consistent deployment instructions.
- Images: all supplied PNG/JPEG files opened and passed format verification. The scanned telegrams/dispatches are legible; the Challenge 008 red tag is visible; the Challenge 028 organizer spectrogram is legible.
- PDF: Challenge 017's PDF opens and its text layer contains the intended recoverable field beneath the drawn redaction bars.
- Audio: Challenges 018 and 028 are valid 44.1 kHz mono PCM WAV files. The DTMF pairs in 018 match the supplied keypad chart. The spectrogram carrier in 028 resolves to the intended 5×7 text.
- Packet captures: the HTTP, DNS, ARP and TLS PCAPs parsed successfully and contain the expected traffic patterns.
- SQLite: the Challenge 011 browser-history database passes `PRAGMA integrity_check` and contains the expected download/visit records.
- ELF: Challenges 006 and 020 are valid Linux x86-64 executables. Their ZIP entries retain executable mode `100755`; standard Info-ZIP extraction preserves this, although Python's generic `zipfile.extractall()` in the test harness did not.
- Other formats: the MBOX parses into five messages; Challenge 022's nested Git repository contains the intended unreachable commit; Challenge 023's nested source map is valid JSON v3; Challenge 031's two XML event exports parse successfully.

### Solve checks

Each challenge's intended workflow was reconstructed independently from the player-side files and compared with the organizer flag. The methods included OSINT record lookup; HTTP stream reconstruction; HTML/CSS/JS source inspection; JPEG header repair; ROT13 and Vigenère decoding; ELF analysis; hidden-file discovery; PNG LSB extraction; EXIF/Base64/password-protected appended ZIP recovery; browser-cookie manipulation; SQLite queries and WebKit timestamp conversion; Wayback capture analysis; DNS TXT decoding; ARP conflict identification; `robots.txt` discovery; PDF text-layer recovery; DTMF analysis; RSA small-exponent integer-cube recovery; reverse-engineering an undocumented ELF command; `/proc` environment parsing; Git unreachable-object recovery; source-map inspection; RDAP/BGP attribution; MIME attachment extraction; reused-XOR-pad recovery; systemd timer/service tracing; spectrogram decoding; TLS SNI extraction; Shamir reconstruction; and Windows Security/Sysmon log correlation.

All 31 expected results were recovered. Challenge 001 was additionally checked against the current official Rubin Museum record: the visual description matches “Mahakala, the Excellent One” and object number `C2005.16.20`. Challenge 013 depends on the Wayback Machine capture for `http://www.python.org/1.5/`; recheck it before the event. Challenge 024 was rechecked on 10 November 2026: ARIN-derived registry data identifies the organization as GitHub (`GITHU`), and current RIPE RIS-backed BGP data shows AS36459 originating `140.82.112.0/20`. For Challenge 019, the exact integer cube appears at `k = 4`. For Challenge 030, all ten possible three-share combinations reconstruct the same 35-byte secret.

### Submission and database integration

- The challenge pages use the expected `/solve` payload shape (`challengeId` and `flag`). The current server handler compares the submitted flag with the server-side `challenges.flag` record and awards points based on the registry challenge's points value.
- All 31 page-level challenge IDs matched their numbered cases.
- The SQL scripts all executed in a test schema with `id`, `flag`, `points`, and `solve_count`; rows 1–26 were pre-seeded and scripts 27–31 inserted new rows. The final 31 flag values matched the author files.
- This was a **schema simulation**, not a migration against the user's live `CTF_data/ctf.sqlite`. Back up the event DB and verify its actual schema before applying the scripts.

### Tests not completed

- Chromium/Playwright navigation to a local HTTP test server was blocked by the execution environment (`ERR_BLOCKED_BY_ADMINISTRATOR`). Therefore, this report does not claim a successful visual/browser-render test.
- The real CTF server was not launched against the user's event database, and no live team account was used for an end-to-end submission.
- No independent Claude, Gemini, or other proprietary-model endpoint was available in the connected tools or local runtime. I cannot claim multi-model testing. The AI-shortcut review below uses GPT-6 reasoning plus recursive archive extraction, text/metadata scanning, Base64 checks, code inspection and independent solve scripts. A true cross-model benchmark would require the player ZIPs to be submitted to those models separately.

## 3. Per-challenge beginner-readiness review

Scores are an instructional assessment of the supplied case page and handouts, not a score for the technical validity of the flag. **5 = very accessible after the workshop; 1 = specialist technique with little scaffolding.**

| ID | Challenge | Solve | Beginner readiness | Notes |
|---:|---|---|---:|---|
| 001 | The Excellent One | Pass | 4/5 | Clear visual clue and exact museum-record objective. Internet research required. Align README's extraction destination with `public/`. |
| 002 | The Quiet Download | Pass | 5/5 | Good Wireshark sequence: HTTP filter → request path → Follow TCP Stream. Clear target path. |
| 003 | The Unseen Build | Pass | 4/5 | Good three-source-fragment lesson. Make sure participants extract/open the supplied portal snapshot rather than only the challenge case page. |
| 004 | A Few Missing Bytes | Pass | 3/5 | Clear `file`/`xxd` path. Add a Windows HxD alternative for students who do not use Linux. |
| 005 | The Half-Turn Message | Pass | 5/5 | The scanned message is legible and the half-alphabet hint is explicit. Good first crypto exercise. |
| 006 | The Maintenance Console | Pass | 3/5 | Executable and validation function are inspectable. Requires Linux x86-64 and Ghidra/Cutter or equivalent; setup should be covered in the workshop. |
| 007 | The Hidden Handover | Pass | 5/5 | The dot-directory and hidden-filename clues make the `ls -la` step discoverable. Good Linux fundamentals challenge. |
| 008 | The Red Tag | Pass | 3/5 | Image clue is visible and the channel clue is fair. Add a one-line tested extraction command and install instructions for `zsteg`/a bit-plane viewer. |
| 009 | The Sealed Handover | Pass | 3/5 | Multi-layer path is logically signposted. Participants need EXIF inspection, Base64 and ZIP password tooling; a tool command sheet would help. |
| 010 | The Forgotten Cookie | Pass* | 3/5 | Developer Tools/cookie manipulation is beginner friendly, but the public JSON exposes the flag directly. Treat as an intentional static-exposure lesson or redesign. |
| 011 | The Last Download | Pass | 3/5 | DB Browser for SQLite is a suitable GUI. Add a ready-to-run SQL query and timestamp conversion example for beginners. |
| 012 | The Telegraph Ledger | Pass | 4/5 | Legible telegram and station-call-sign clue. Vigenère is an appropriate Easy-Medium crypto task. |
| 013 | The First Footprint | Pass | 3/5 | Exact URL and Wayback path are clear. Explain HTTP 200/successful captures and provide a fallback snapshot if Internet Archive is unavailable. |
| 014 | The Resolver's Receipt | Pass | 4/5 | Wireshark DNS filter, TXT-record clue and Base64 step are explicit. Good next step after the HTTP PCAP. |
| 015 | The Duplicate Address | Pass | 4/5 | ARP filter and known gateway IP are supplied. Comparing the inventory MAC to sender MAC is clear. |
| 016 | The Crawler's Blind Spot | Pass | 5/5 | `robots.txt` is a familiar web discovery concept and the record's transport encoding is signposted. |
| 017 | The Redacted Export | Pass | 4/5 | The redaction flaw is clear. `pdftotext` plus copy/select fallback helps both CLI and GUI users. |
| 018 | The Handover Call | Pass | 4/5 | Excellent DTMF reference table and explicit ignore-calibration/confirmation instructions. Audacity spectrum steps are sufficient. |
| 019 | The Small Exponent | Pass | 2/5 | Exact-cube attack is mathematically sound but the `c + k·n` search and byte conversion are a jump for beginners. Provide starter Python and consider Medium. |
| 020 | The Quiet Diagnostic | Pass | 2/5 | The arithmetic inverse is explained, but ELF analysis and hidden-command discovery are difficult for a beginner. Add `chmod +x`, Linux/WSL2 note and a sample hex-decoding script. |
| 021 | The Orphaned Worker | Pass | 4/5 | Process listing and NUL-separated environment command are supplied. Good `/proc` investigation after the Linux dotfile task. |
| 022 | The Unpublished Revision | Pass | 4/5 | The `git fsck`/`git show` workflow is explicit. Remove the loose duplicate repository so archive extraction is not skipped. |
| 023 | The Map Left Behind | Pass | 3/5 | Clear `sourceMappingURL` → `sourcesContent` trail. Remove the loose duplicate `portal_snapshot/` so learners must inspect the source map. |
| 024 | The Prefix Behind the Portal | Pass | 4/5 | Strong analyst cards with the exact ARIN RDAP URL and BGP route hint. Internet dependency and live-data revalidation are the main risks. |
| 025 | The Mailbox Fragment | Pass | 3/5 | Useful MIME field guide. Five messages and an explicit X-header make the correct message findable. A simple `mailbox` Python starter would help. |
| 026 | The Reused Pad | Pass | 4/5 | The XOR formula and known-plaintext clue are well scaffolded. Suitable Easy-Medium cryptography. |
| 027 | The Timer's Last Tick | Pass | 3/5 | Unit/service/EnvironmentFile trace is clearly explained. Remove the loose duplicate snapshot and fix the registry entry. |
| 028 | The Glass Harbor | Pass | 5/5 | Excellent beginner instructions: Audacity, linear frequency axis, 1–3.5 kHz range, 8192 window and 5×7 reading direction. |
| 029 | The Name Before Encryption | Pass | 4/5 | Exact Wireshark SNI filter, host inventory and time window make the solve clear. |
| 030 | The Three-Key Cabinet | Pass | 2/5 | The Lagrange formula and modulus are provided, but coding modular interpolation across 35 byte positions is a substantial jump. Add a starter script or a worked one-byte example; consider Medium. |
| 031 | The Logon That Stayed | Pass | 4/5 | The Security 4624/Sysmon Event 1 field guide is strong. Clarify that the files are XML exports, not native EVTX, as the package already notes. |

`*` Challenge 010 is technically solvable through its intended cookie workflow, but the intended interaction is not necessary because of the direct JSON disclosure.

## 4. AI-assisted and non-linear shortcut review

This is a file-level shortcut analysis, not a cross-model benchmark. I recursively unpacked nested evidence archives to five levels, searched for exact flags and full-flag Base64 encodings, inspected source/metadata/config files, and ran independent extraction scripts.

### Findings

1. **Challenge 010 — direct plaintext flag in public JSON (high).** `public/challenges/web_002/portal/entries/18.json` contains the exact flag. A script or AI with package access can read it directly without inspecting or changing `vault_record`. This is the clearest unintended shortcut.
2. **Challenge 023 — loose source-map snapshot (high).** The participant ZIP contains `portal_snapshot/src/internal/handover.js` and `portal_snapshot/static/js/site.min.js.map` at its top level, as well as the intended nested portal ZIP. The loose source file exposes the encoded handover directly, bypassing the `sourceMappingURL`/`sourcesContent` investigation. Remove the top-level duplicate.
3. **Challenge 027 — loose system snapshot (high).** The participant ZIP contains `host_snapshot/etc/northpier/reconcile.env` as a loose directory in addition to the intended host-snapshot tarball. A solver can open the target config immediately and skip journal → timer → service tracing. Remove the top-level duplicate.
4. **Challenge 022 — loose Git repository (medium).** A top-level `repo_work/northpier-portal/.git` copy accompanies the intended webroot ZIP. This skips archive extraction, but still requires the intended Git unreachable-object investigation. Remove the duplicate for a cleaner path.

### Data embedded in the intended evidence

The following scans found flag material inside the actual challenge evidence, as expected for the relevant task, rather than in an unrelated metadata/answer file:

- Challenge 002: cleartext HTTP report body in the PCAP.
- Challenge 007: flag in the hidden note inside the nested workspace ZIP.
- Challenge 014: Base64 token in a DNS TXT response in the PCAP.
- Challenge 016: Base64 token in the intended archive record.
- Challenge 021: Base64 token in the `environ` file inside the supplied procfs archive.
- Challenge 023: Base64 token in the intended source-map/source payload; the loose duplicate is the packaging issue.
- Challenge 027: Base64 token in the intended environment file; the loose duplicate is the packaging issue.

These are not all defects: the evidence itself must contain the data being investigated. The concern is whether a duplicate or unrelated public file lets a solver skip the intended technique.

### Model availability limitation

No separate Claude/Gemini/other LLM inference endpoint was available in the connected tool registry or local runtime. I therefore cannot report “tested with multiple AI models.” GPT-6 reasoning and local scripts were used to emulate an adversarial file-aware solver. For a true multi-model benchmark, supply the same participant ZIPs and the same prompt to each model with file-analysis/code-execution tools enabled, and record whether it follows the intended path or jumps directly to the flag.

## 5. Platform compatibility

The current platform's challenge-list renderer reads `challenge.title`, `challenge.description`, `challenge.link` and `challenge.points`. In `main.js`, the link is set using `challenge.link`; `path` and `metadata` are not read by that renderer. The server `/solve` handler accepts the `challengeId` and `flag` fields and compares the flag against the server-side `challenges` table.

- Registry entries 001–026 use the expected `title` / `id` / `description` / `link` / `points` shape.
- Entries 027–031 use `id` / `title` / `category` / `points` / `path` / `metadata`. They omit both `description` and `link`. **The platform will not render their links/descriptions correctly until converted.**
- The page forms' challenge IDs and `/solve` payload field names match the server-side contract.
- The static assets for 027–031 include `public/challenge27.html` through `public/challenge31.html` and metadata JSON files. The metadata files do not compensate for the missing fields in the currently used challenge list renderer.

### Compatible registry entries for 027–031

Use the same shape as existing entries. These are ready-to-copy examples; keep the exact `description` text you want shown in the challenge card:

```js
{
  title: "The Timer's Last Tick",
  id: 27,
  description: "Trace the 02:17 UTC systemd timer to its service and environment file, then decode the handover value.",
  link: "challenge27.html",
  points: 125
},
{
  title: "The Glass Harbor",
  id: 28,
  description: "Inspect a WAV spectrogram and read the 5-by-7 message hidden in its frequency pattern.",
  link: "challenge28.html",
  points: 125
},
{
  title: "The Name Before Encryption",
  id: 29,
  description: "Correlate workstation and time-window evidence in a TLS PCAP to recover the ClientHello SNI hostname.",
  link: "challenge29.html",
  points: 125
},
{
  title: "The Three-Key Cabinet",
  id: 30,
  description: "Use any three of five Shamir shares and modular interpolation to reconstruct the escrow secret.",
  link: "challenge30.html",
  points: 125
},
{
  title: "The Logon That Stayed",
  id: 31,
  description: "Correlate a Windows 4624 logon with a Sysmon process event and decode the PowerShell command.",
  link: "challenge31.html",
  points: 125
}
```

## 6. Deployment hygiene

The working directory contains old challenge drafts and alternate ZIPs in addition to the canonical 001–031 files. Do not deploy every `*.zip` in the directory.

Use only the 31 canonical pairs named `static_challenge_001_excellent_one_*` through `static_challenge_031_logon_that_stayed_*`.

Exclude:

- the alternate/older `static_challenge_010_missing_name_player.zip` and `static_challenge_010_missing_name_author.zip` pair (both exist; it is not the canonical Challenge 010),
- older `challenge_001_*` through `challenge_007_*` drafts,
- `ctf_basic_challenges_*_bundle.zip`, and
- build/extraction folders such as `static_challenge_*_build`, `challenge027_build`, `challenge028_build` and `ctf_audit_extract`.

Before the event:

1. Convert 027–031 registry entries to the current platform schema.
2. Rebuild 022, 023 and 027 participant/author packages after removing their loose duplicate directories.
3. Decide whether to keep Challenge 010 as an intentionally exposed static-client lesson or replace its mechanism.
4. Add simple starter commands/scripts for 008, 019, 020 and 030.
5. Install the canonical 31 packages into a clean copy of the platform, start the API and frontend, then test one correct and one incorrect submission for each challenge using a disposable team. Confirm no flag appears in frontend bundles, source maps, page HTML, or player-facing metadata.
6. Revalidate OSINT records in 001, 013 and 024 shortly before event day. Keep a fallback PDF/screenshot/record snapshot so an external site outage does not stall a 3-hour event.

---

## 7. Final verdict

**Solvability:** 31/31 intended answer paths independently reconstructed.  
**Primary ZIP integrity:** 62/62 pass.  
**Evidence parsing:** all tested asset formats pass.  
**Organizer setup:** all 31 SQL scripts pass against the test schema.  
**Player-page JavaScript:** 31/31 syntax checks pass.  
**Platform registry compatibility:** 026/031 entries align; 027–031 need conversion.  
**Unintended shortcuts:** 010, 022, 023 and 027 identified; 010 is the direct-flag issue.  
**Visual browser test:** not completed because local browser navigation was blocked by the environment.  
**Cross-model AI test:** not completed; no external model endpoints were available. File-aware AI-style shortcut inspection was completed.

**Release decision:** The set is close, but it is **not release-ready unchanged**. Apply the high-priority fixes and perform one clean-platform browser + solve-submission run before the event.
