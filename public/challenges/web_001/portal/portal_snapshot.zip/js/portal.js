/* NORTHSTAR ARCHIVE / CLIENT INTERACTIONS
 * Build 2.8.14
 */
"use strict";

const responseText = document.getElementById("responseText");
const indexButton = document.getElementById("indexButton");
const statusButton = document.getElementById("statusButton");

indexButton.addEventListener("click", () => {
  responseText.textContent = "Index service: 12 public notices available. Current mirror is read-only.";
});

statusButton.addEventListener("click", () => {
  responseText.textContent = "Mirror status: ONLINE. Last synchronization completed successfully.";
});

// Segment 3 of 3: inspect_the_sources}
